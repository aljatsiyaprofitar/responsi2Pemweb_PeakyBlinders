<?php
session_start();
require 'includes/functions.php'; // Panggil koneksi

$username = $_SESSION['username'];

// 1. Ambil ID User Asli
$u_res = mysqli_query($koneksi, "SELECT id FROM users WHERE username='$username'");
$u_data = mysqli_fetch_assoc($u_res);
$user_id = $u_data['id'];

// 2. Ambil Semua Karakter Roleplay milik User (Untuk Dropdown)
$my_chars = mysqli_query($koneksi, "SELECT * FROM roleplay_chars WHERE user_id = $user_id");

// 3. Tentukan Karakter Aktif (Default ambil yang terakhir dibuat/dimainkan)
if (!isset($_SESSION['active_rp_id'])) {
    // Ambil karakter pertama jika session kosong
    $first_char = mysqli_fetch_assoc($my_chars);
    if ($first_char) {
        $_SESSION['active_rp_id'] = $first_char['rp_id'];
        // Reset pointer array agar dropdown bisa looping ulang
        mysqli_data_seek($my_chars, 0); 
    }
}

// 4. Ambil Data Karakter Aktif (Nama & Score)
$active_id = $_SESSION['active_rp_id'] ?? 0;
$active_char_query = mysqli_query($koneksi, "SELECT * FROM roleplay_chars WHERE rp_id = $active_id");
$active_char = mysqli_fetch_assoc($active_char_query);

// Logic Ganti Karakter via Dropdown
if (isset($_GET['switch_char'])) {
    $_SESSION['active_rp_id'] = $_GET['switch_char'];
    header("Location: roleplay_mission.php");
}
?>

<!DOCTYPE html>
<html>
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta charset="utf-8" />
    <link rel="stylesheet" href="Mission.css" />
  </head>
  <body>
    <div class="desktop">
      <div class="rectangle"></div>
      <div class="text-wrapper">Aljatsiya</div>
      <div class="div">Logout</div>
      <div class="text-wrapper-2">Character</div>
      <div class="text-wrapper-3">Roleplay</div>
      <div class="text-wrapper-4">Home</div>
      <img class="vector" src="img/vector-2.svg" />
      <img class="img" src="img/vector-6.svg" />
      <img class="vector-2" src="img/vector-3.svg" />
      <img class="vector-3" src="img/vector-7.svg" />
      <img class="vector-4" src="img/vector-8.svg" />
      <img class="vector-5" src="img/image.svg" />
      <div class="rectangle-2"></div>
      <img class="vector-6" src="img/vector-5.svg" />
      <img class="vector-7" src="img/vector.svg" />
      <img class="vector-8" src="img/vector-4.svg" />
      <img class="peaky-blinders" src="img/peaky-blinders-4-removebg-preview-1.png" />
      <img class="peaky-blinders-2" src="img/peaky-blinders-6-removebg-preview-1.png" />
      <img class="rectangle-3" src="img/rectangle-58.png" />
      <img class="rectangle-4" src="img/rectangle-61.svg" />
      <img class="rectangle-5" src="img/rectangle-63.png" />
      <div class="text-wrapper-5">Start Mission</div>
      <img class="rectangle-6" src="img/rectangle-62.svg" />
      <div class="rectangle-7"></div>
      <div class="text-wrapper-6">Start Mission</div>
      <img class="img-2" src="img/5d4fb01e263d159c69f45466854b5adb-720w-1.png" />
      <div class="text-wrapper-7">Shadows of Garrison</div>
      <div class="text-wrapper-8">Whispers in the Cut</div>
      <p class="p">A Message in Bloody Ink</p>
      <p class="garrison-tavern">
        Garrison Tavern mulai dipenuhi bisikan tentang sosok asing yang berkeliaran di sekitar pub setelah tengah
        malam.Tak ada yang tahu siapa dia, tapi jejak langkahnya selalu berhenti tepat di depan pintu belakang—seolah
        menunggu seseorang keluar.<br />Tugasmu sederhana: ikuti bayangannya, dan cari tahu apakah ini ancaman… atau
        awal dari sesuatu yang jauh lebih besar.
      </p>
      <p class="bisikan-tentang">
        Bisikan tentang pengkhianatan baru terdengar dari The Cut, gang sempit tempat rahasia biasanya mati bersama
        malam.<br />Kamu harus menemukan informan yang bersembunyi sebelum kabar itu tersebar ke tangan Sabini.<br />Melangkahlah
        pelan—setiap sudut bisa menjadi mata yang mengawasi.
      </p>
      <p class="sebuah-surat">
        Sebuah surat bertinta merah muncul di meja belakang Garrison, ditinggalkan oleh seseorang yang tahu terlalu
        banyak.<br />Pesannya singkat, namun cukup untuk menandakan bahwa bahaya sudah sangat dekat.Kamu harus mencari
        siapa pengirimnya sebelum “peringatan” berubah menjadi pembantaian.
      </p>
      <img class="pindown-io" src="img/pindown-io.png" />
      <img class="pindown-io-2" src="img/pindown-io-craftcat2000-1765034671-1.png" />
      <div class="text-wrapper-9">Mission</div>
      <div class="rectangle-8"></div>
      <div class="text-wrapper-10">Start Mission</div>
      <img class="rectangle-9" src="img/rectangle-65.png" />
      <div class="high-score">High score</div>
      <div class="text-wrapper-11">0</div>
      <img class="group" src="img/group-10.png" />
      <img class="mask-group" src="img/mask-group.png" />
      <img class="group-2" src="img/group-11.png" />
      <div class="text-wrapper-12">John</div>
      <div class="text-wrapper-13">New Character</div>
    </div>
  </body>
</html>
