<?php
session_start();
// Ambil pesan kata-kata terakhir dari session
$death_msg = $_SESSION['game_over_msg'] ?? "You died in the streets of Birmingham.";
?>

<!DOCTYPE html>
<html>
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta charset="utf-8" />
    <link rel="stylesheet" href="GameOver.css" />
  </head>
  <body>
    <div class="desktop">

      <div class="header"></div>

        <a href="index.html" class="nav-link">
            <div class="nav-item-container nav-home">
                <img class="nav-icon" src="Avatar img/home.png" />
                <div class="nav-text home-text">Home</div>
            </div>
        </a>

        <a href="Karakter.html" class="nav-link">
            <div class="nav-item-container nav-character">
                <img class="nav-icon" src="Avatar img/character.png" />
                <div class="nav-text character-text">Character</div>
            </div>
        </a>

        <a href="Avatar.html" class="nav-link">
            <div class="tanda"></div>
            <div class="nav-item-container nav-roleplay">
                <img class="nav-icon" src="Avatar img/roleplay.png" />
                <div class="nav-text roleplay-text">Roleplay</div>
            </div>
        </a>

        <a href="Start.html" class="nav-link">
            <div class="nav-item-container nav-profile">
                <img class="nav-icon" src="Avatar img/profile.png" />
                <div class="nav-text profile-text">Aljatsiya</div>
            </div>
        </a>

        <a href="Halaman1.html" class="nav-link">
            <div class="nav-item-container nav-logout">
                <img class="nav-icon" src="Avatar img/logout.png" />
                <div class="nav-text logout-text">Logout</div>
            </div>
        </a>
        <a href="Halaman1.html" class="nav-link">
            <div class="nav-item-container nav-logout">
                <img class="nav-icon logout-icon" src="Avatar img/logout.png">
                <div class="nav-text logout-text">Logout</div>
            </div>
        </a>

      <img class="background-tiang" src="Missions img/background tiang.png" />
      <img class="background-topi" src="Missions img/background topi.png" />
      
      <img class="rectangle-cerita" src="Missions img/rectangle cerita.png" />

      <div class="judul">Game Over</div>
      
      </p>
      <div class="text">
        <p>
          “Yang lari dari tugas pertama…” bisik suara gelap itu.  “…tidak pernah sampai ke tugas kedua.”
        </p>
      </div>
      
      <a href="Mission.html">
        <img class="pilihan1" src="Missions img/Rectangle opsi.png" />
        <div class="text1">Kembali ke Mission</div>
      </a>

    </div>
  </body>
</html>