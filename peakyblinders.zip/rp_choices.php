<!DOCTYPE html>
<html>
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta charset="utf-8" />
    <link rel="stylesheet" href="Mission1f.css" />
  </head>
  <body>
    <div class="desktop">

      <div class="header"></div>

        <a href="index.html" class="nav-link">
            <div class="nav-item-container nav-home">
                <img class="nav-icon" src="Avatar img/home.png" />
                <div class="nav-text home-text">Home</div>
            </div>
        </a>

        <a href="Karakter.html" class="nav-link">
            <div class="nav-item-container nav-character">
                <img class="nav-icon" src="Avatar img/character.png" />
                <div class="nav-text character-text">Character</div>
            </div>
        </a>

        <a href="Avatar.html" class="nav-link">
            <div class="tanda"></div>
            <div class="nav-item-container nav-roleplay">
                <img class="nav-icon" src="Avatar img/roleplay.png" />
                <div class="nav-text roleplay-text">Roleplay</div>
            </div>
        </a>

        <a href="Start.html" class="nav-link">
            <div class="nav-item-container nav-profile">
                <img class="nav-icon" src="Avatar img/profile.png" />
                <div class="nav-text profile-text">Aljatsiya</div>
            </div>
        </a>

        <a href="Halaman1.html" class="nav-link">
            <div class="nav-item-container nav-logout">
                <img class="nav-icon" src="Avatar img/logout.png" />
                <div class="nav-text logout-text">Logout</div>
            </div>
        </a>
        <a href="Halaman1.html" class="nav-link">
            <div class="nav-item-container nav-logout">
                <img class="nav-icon logout-icon" src="Avatar img/logout.png">
                <div class="nav-text logout-text">Logout</div>
            </div>
        </a>

      <img class="background-tiang" src="Missions img/background tiang.png" />
      <img class="background-topi" src="Missions img/background topi.png" />
      
      <img class="rectangle-cerita" src="Missions img/rectangle cerita.png" />

      <div class="judul-cerita">Shadow Of Garrison</div>
      
      </p>
      <div class="misi">
        <p>
          Kabut Birmingham turun seperti tirai kematian malam itu. 
          Lampu-lampu jalan berkelip lelah, seolah tidak sanggup menerangi rahasia 
          yang disembunyikan Small Heath. Deru pabrik, bau arang, dan suara langkah-langkah gelisah 
          menjadi musik latar kejadian-kejadian yang tidak pernah diceritakan kepada siapapun.
        </p>

        <p>
          Di tengah kegelapan itu—kaulah pendatang baru. Wajah asing dengan masa lalu yang tak banyak orang peduli, 
          namun cukup untuk membuat Arthur Shelby menatapmu dengan tajam… seperti menilai apakah kau layak hidup 
          atau layak dikubur di belakang Garrison.
        </p>

        <p class="quote">
          “Dengarkan baik-baik,” katanya pelan, tapi dengan nada penuh penekanan.<br>
          “Di tempat ini, satu keputusan salah bisa membuatmu hilang… tanpa nama, tanpa jejak.”
        </p>

        <p>
          Hari ini adalah ujian pertamamu. Satu langkah keliru, dan Small Heath akan menelanimu hidup-hidup. 
          Namun jika kau berhasil… kau bukan sekadar pendatang lagi.
        </p>

        <p>
          Kau menjadi bagian dari keluarga yang ditakuti seluruh Birmingham.
        </p>
      </div>
      
      <a href="Mission2.html">
        <img class="pilihan1" src="Missions img/Rectangle opsi.png" />
        <div class="text1">Pergi ke Garrison seperti perintah.</div>
      </a>

      <a href="GameOver.html">
        <img class="pilihan2" src="Missions img/Rectangle opsi.png" />
        <div class="text2">Lari bersembunyi di rumah.</div>
      </a>

    </div>
  </body>
</html>

