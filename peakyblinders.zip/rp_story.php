<?php
session_start();
require 'config/koneksi.php';

// Ambil ID Cerita (Default 1 jika baru mulai)
$story_id = isset($_GET['story_id']) ? intval($_GET['story_id']) : 1;

// 1. Ambil Data Cerita
$query = "SELECT * FROM game_stories WHERE story_id = $story_id";
$result = mysqli_query($koneksi, $query);
$story = mysqli_fetch_assoc($result);

// 2. LOGIC CEK GAME OVER (Ini bagian penting permintaanmu)
if ($story['is_game_over'] == 1) {
    // Simpan pesan kematian ke session biar bisa ditampilkan di halaman Game Over
    $_SESSION['game_over_msg'] = $story['story_text'];
    
    // Redirect ke halaman Game Over terpisah
    header("Location: rp_game_over.php");
    exit;
}

// 3. Ambil Pilihan (Jika bukan game over)
$choices = [];
$c_query = "SELECT * FROM game_choices WHERE story_id = $story_id";
$c_result = mysqli_query($koneksi, $c_query);
while($row = mysqli_fetch_assoc($c_result)) {
    $choices[] = $row;
}
?>

<!DOCTYPE html>
<html>
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta charset="utf-8" />
    <link rel="stylesheet" href="Mission1.css" />
  </head>
  <body>
    <div class="desktop">

      <div class="header"></div>

        <a href="index.html" class="nav-link">
            <div class="nav-item-container nav-home">
                <img class="nav-icon" src="Avatar img/home.png" />
                <div class="nav-text home-text">Home</div>
            </div>
        </a>

        <a href="Karakter.html" class="nav-link">
            <div class="nav-item-container nav-character">
                <img class="nav-icon" src="Avatar img/character.png" />
                <div class="nav-text character-text">Character</div>
            </div>
        </a>

        <a href="Avatar.html" class="nav-link">
            <div class="tanda"></div>
            <div class="nav-item-container nav-roleplay">
                <img class="nav-icon" src="Avatar img/roleplay.png" />
                <div class="nav-text roleplay-text">Roleplay</div>
            </div>
        </a>

        <a href="Start.html" class="nav-link">
            <div class="nav-item-container nav-profile">
                <img class="nav-icon" src="Avatar img/profile.png" />
                <div class="nav-text profile-text">Aljatsiya</div>
            </div>
        </a>

        <a href="Halaman1.html" class="nav-link">
            <div class="nav-item-container nav-logout">
                <img class="nav-icon" src="Avatar img/logout.png" />
                <div class="nav-text logout-text">Logout</div>
            </div>
        </a>
        <a href="Halaman1.html" class="nav-link">
            <div class="nav-item-container nav-logout">
                <img class="nav-icon logout-icon" src="Avatar img/logout.png">
                <div class="nav-text logout-text">Logout</div>
            </div>
        </a>

      <img class="background-tiang" src="Missions img/background tiang.png" />
      <img class="background-topi" src="Missions img/background topi.png" />
      
      <img class="rectangle-cerita" src="Missions img/rectangle cerita.png" />

      <div class="judul-cerita">Shadow Of Garrison</div>
      
      </p>
      <div class="misi">
        <p>
          Kabut Birmingham turun seperti tirai kematian malam itu. 
          Lampu-lampu jalan berkelip lelah, seolah tidak sanggup menerangi rahasia 
          yang disembunyikan Small Heath. Deru pabrik, bau arang, dan suara langkah-langkah gelisah 
          menjadi musik latar kejadian-kejadian yang tidak pernah diceritakan kepada siapapun.
        </p>

        <p>
          Di tengah kegelapan itu—kaulah pendatang baru. Wajah asing dengan masa lalu yang tak banyak orang peduli, 
          namun cukup untuk membuat Arthur Shelby menatapmu dengan tajam… seperti menilai apakah kau layak hidup 
          atau layak dikubur di belakang Garrison.
        </p>

        <p class="quote">
          “Dengarkan baik-baik,” katanya pelan, tapi dengan nada penuh penekanan.<br>
          “Di tempat ini, satu keputusan salah bisa membuatmu hilang… tanpa nama, tanpa jejak.”
        </p>

        <p>
          Hari ini adalah ujian pertamamu. Satu langkah keliru, dan Small Heath akan menelanimu hidup-hidup. 
          Namun jika kau berhasil… kau bukan sekadar pendatang lagi.
        </p>

        <p>
          Kau menjadi bagian dari keluarga yang ditakuti seluruh Birmingham.
        </p>
      </div>
      
      <a href="Mission1f.html">
        <img class="box-skor" src="Missions img/rectangle next back.png" />
        <div class="text-skor">Next</div>
      </a>

    </div>
  </body>
</html>